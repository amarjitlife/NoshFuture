
#include <stdio.h>
#include <limits.h>

//______________________________________________________

int unsafeSum(int x, int y) {
	return x + y;
}

// long long sum(long long x, long long y) {
// 	return x + y;
// }


//______________________________________________________

// GOOD DESIGN
signed int safeSum(signed int a, signed int b) {
	  signed int result = 0;
	  // Type Safe Code
	  // Respecting Type Definition
	  // int Type Definition
	  if (((b > 0) && (a > (INT_MAX - b))) ||
	      ((b < 0) && (a < (INT_MIN - b)))) {
	  
	  		printf("Can't Calculate Sum For Given x And y Values")
	  
	  } else {
	  
	    	result = a + b;
	  }

	  return result;
}

//______________________________________________________


void playWithSum() {
	int x = 10, y = 20;
	int result = 0;

	result = sum( x, y);
	printf("\nResult : %d", result );

	x = 2147483647;
	y = 1;
	printf("\n x: %d \n y: %d", x, y);
	result = sum( x, y);
	printf("\nResult : %d", result );

	x = -2147483648;
	y = -2;
	printf("\n x: %d \n y: %d", x, y);
	result = sum( x, y);
	printf("\nResult : %d", result );
}

// Function : playWithSum
// Result : 30
//  x: 2147483647 
//  y: 1
// Result : -2147483648
//  x: -2147483648 
//  y: -2
// Result : 2147483646

void main() {
	printf("\nFunction : playWithSum");
	playWithSum();
}

