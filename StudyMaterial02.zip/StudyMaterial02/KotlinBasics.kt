
package learnKotlin

//________________________________________________________________
//________________________________________________________________

// Creating New Type Color
// Color Type
//		Range Color Type = { RED, GREEN, BLUE, YELLOW, VIOLET, UNKNOWN }
enum class Color {
	RED, GREEN, BLUE, YELLOW, VIOLET, UNKNOWN
}

fun getStringForColor( color: Color ): String {
	// when Is Type Safe Expression
	//		Respect Type Definition
	return when( color ) {
		Color.RED 		-> "Red Color"
		Color.GREEN 	-> "Green Color"

		// error: 'when' expression must be exhaustive, add necessary 'BLUE' branch 
		//	or 'else' branch instead
		
		// Which Design Choice Is Better?
		Color.BLUE  	-> "Blue Color"
		Color.YELLOW 	-> "Yellow Color"
		Color.VIOLET 	-> "Violet Color"
		Color.UNKNOWN 	-> "Unkown Color"

		// else 		-> "Unknown Color"
	}
	//BETTER DESIGN
	//		Cover All The Exhaustive Cases i.e. Range of Type
}

fun getStringForColorAgain( color: Color ) = when( color ) {
		Color.RED 		-> "Red Color"
		Color.GREEN 	-> "Green Color"
		Color.BLUE  	-> "Blue Color"
		Color.YELLOW 	-> "Yellow Color"
		Color.VIOLET 	-> "Violet Color"
		Color.UNKNOWN 	-> "Unkown Color"

		// else 		-> "Unknown Color"
}


fun playWithColors() {
	println( Color.RED )
	println( Color.GREEN )
	println( Color.BLUE )

	println( getStringForColor( Color.RED ) )
	println( getStringForColor( Color.GREEN ) )
	println( getStringForColor( Color.BLUE ) )

	println( getStringForColorAgain( Color.RED ) )
	println( getStringForColorAgain( Color.GREEN ) )
	println( getStringForColorAgain( Color.BLUE ) )
}

//________________________________________________________________

fun mixColors( c1: Color, c2: Color ) = when ( setOf( c1, c2) ) {
	setOf( Color.BLUE, Color.GREEN ) 	-> Color.YELLOW
	setOf( Color.RED, Color.BLUE   )    -> Color.VIOLET
	else ->	throw Exception("Unknown Color")
}

// DESIGN PRINCIPLE
//		Exceptions Are Not That Exceptional Such That It Should Break Your Design

// Closure Law
fun mixColorsAgain( c1: Color, c2: Color ) : Color {
	return when ( setOf( c1, c2) ) {
		setOf( Color.BLUE, Color.GREEN ) 	-> Color.YELLOW
		setOf( Color.RED, Color.BLUE   )    -> Color.VIOLET
		else ->	Color.UNKNOWN
	}
}

fun playWithColorsAgain() {
	println( mixColors( Color.RED, Color.BLUE ) )
	println( mixColors( Color.GREEN, Color.BLUE ) )
	// println( mixColors( Color.BLUE, Color.YELLOW ) )

	println( mixColorsAgain( Color.RED, Color.BLUE ) )
	println( mixColorsAgain( Color.GREEN, Color.BLUE ) )
}

//________________________________________________________________
//________________________________________________________________
//________________________________________________________________
//________________________________________________________________
//________________________________________________________________
//________________________________________________________________
//________________________________________________________________

fun main() {
	println("\nFunction : playWithColors")
	playWithColors()

	println("\nFunction : playWithColorsAgain")
	playWithColorsAgain()

	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
}

