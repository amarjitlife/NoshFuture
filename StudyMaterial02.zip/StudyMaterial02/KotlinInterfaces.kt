
package learnKotlin

//____________________________________________________________________
//____________________________________________________________________

// error: this type is final, so it cannot be inherited from

// DESIGN PRINCIPLE
//		Design Toward Interfaces Rather Than Concrete Classes
//				Your Code Design Should Be Governed By Interfaces
//		Brings Contract In System
// WHAT To Do It!
interface Superpower {
	fun fly()
	fun saveWorld()
}

// CONCRETE CLASSES
// HOW, WHEN, WHERE, WHICH WAY TO DO IT!
// I Liked Spiderman
// Implementating Interace Superpower
class Spiderman : Superpower {
	override fun fly() 		 { println("Fly Like Spiderman!") }
	override fun saveWorld() { println("Save World Like Spiderman!") }	
}

class Thor : Superpower {
	override fun fly() 		 { println("Fly Like Thor!") }
	override fun saveWorld() { println("Save World Like Thor!") }	
}

// I Liked Spiderman
class Superman : Superpower {
	override fun fly() 		 { println("Fly Like Superman!") }
	override fun saveWorld() { println("Save World Like Superman!") }	
}

// I Liked Spiderman
open class Heman {
	open fun fly() 		 { println("Fly Like Heman!") }
	open fun saveWorld() { println("Save World Like Heman!") }	
}

// I Want To Become Like Spiderman
// Using Inheritance
// class Human : Spiderman() {
// class Human : Superman() {

class HumanDesign1 : Heman() {
	override fun fly() 		  { super.fly() 	  }// { println("Fly Like Human!") }
	override fun saveWorld()  { super.saveWorld() }// { println("Save World Like Human!") }
}


// Polymorpism
// 		Using Composition 
class HumanDesign2 {
	// Delegating The Power Flying and Saving World
	var power : Superpower? = null
	fun fly() 		  { power?.fly() 	  }// { println("Fly Like Human!") }
	fun saveWorld()   { power?.saveWorld() }// { println("Save World Like Human!") }
}

fun playWithHuman() {
	var human1 = HumanDesign1()
	human1.fly()
	human1.saveWorld()

	var human2 = HumanDesign2()
	human2.power = Spiderman() // Configuring Spiderman
	human2.fly()
	human2.saveWorld()

	// 
	human2.power = Superman() // Configuring Superman
	human2.fly()
	human2.saveWorld()

	human2.power = Thor()		// Configuring Thor
	human2.fly()
	human2.saveWorld()	
}

//____________________________________________________________________
//____________________________________________________________________

// All Functions Are Indepedent Units

// Function Type
//		(Int, Int) -> Int
fun sum(x: Int, y: Int) : Int { return x + y }

fun sub(x: Int, y: Int) : Int { return x - y }

fun mul(x: Int, y: Int) : Int { return x * y }

// Calculator Polymorphic
// Function Type
//		(Int, Int, (Int, Int) -> Int ) -> Int
//	Function Type : Contract

fun calculator( x: Int, y: Int, operation: (Int, Int) -> Int ) : Int {
	if operation != null {
		return operation(x, y)
	} return {
		return 0
	}
}

fun playWithCalculator() {
	var x = 40
	var y = 20
	var result: Int

	// Configuring With Sum
	result = calculator(x, y, ::sum )
	println("Result = $result ")

	// Configuring With Sub
	result = calculator(x, y, ::sub )
	println("Result = $result ")

	// Configuring With Sub
	result = calculator(x, y, ::mul )
	println("Result = $result ")

	var something: (Int, Int) -> Int = ::sum
	result = something(x, y)
	println("Result = $result ")

	var somethingAgain: (Int, Int, (Int, Int) -> Int) -> Int = ::calculator
	result = somethingAgain(x, y, ::mul)
	println("Result = $result ")	
}


//____________________________________________________________________
//____________________________________________________________________
//____________________________________________________________________
//____________________________________________________________________


fun main() {
	playWithHuman()
	playWithCalculator()
}


