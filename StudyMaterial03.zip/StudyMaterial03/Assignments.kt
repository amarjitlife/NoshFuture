//________________________________________________________________
//________________________________________________________________

ASSIGNMENT A01: EXPLORATION AND EXPERIMENTATION ASSIGNMENT

	1. In Mathematics What Is Divide By Zero?

	2. Compare Output Of Following Expressions 
			In C/C++/Java/Kotlin and Python

	3. Which Programming Language Implements
			Or Near To Mathematical Definition

		System.out.println( 1.0 / 0.0 );
		System.out.println( -1.0 / 0.0 );
		System.out.println( 0.0 / 0.0 );

//________________________________________________________________

ASSIGNMENT A02: EXPLORATION AND EXPERIMENTATION ASSIGNMENT

	In C/C++/Java/Kotlin/Python
	1. What Will Be Output Of Following Lines Of Code
			Reason The Output
	
		System.out.println( 1.0 / 0.0 == Double.POSITIVE_INFINITY );
		System.out.println( -1.0 / 0.0 == Double.NEGATIVE_INFINITY );
		System.out.println( 0.0 / 0.0 == Double.NaN );

//________________________________________________________________
//________________________________________________________________
//________________________________________________________________
//________________________________________________________________
//________________________________________________________________
//________________________________________________________________
//________________________________________________________________

