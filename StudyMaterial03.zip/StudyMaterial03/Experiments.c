
#include <stdio.h>
#include <limits.h>

//______________________________________________________

int unsafeSum(int x, int y) {
	return x + y;
}

// long long sum(long long x, long long y) {
// 	return x + y;
// }

void playWithSum() {
	int x = 10, y = 20;
	int result = 0;

	result = unsafeSum( x, y);
	printf("\nResult : %d", result );

	x = 2147483647;
	y = 1;
	printf("\n x: %d \n y: %d", x, y);
	result = unsafeSum( x, y);
	printf("\nResult : %d", result );

	x = -2147483648;
	y = -2;
	printf("\n x: %d \n y: %d", x, y);
	result = unsafeSum( x, y);
	printf("\nResult : %d", result );
}

//______________________________________________________

// GOOD DESIGN
signed int safeSum(signed int a, signed int b) {
	  signed int result = 0;
	  // Type Safe Code
	  // Respecting Type Definition
	  // int Type Definition
	  if (((b > 0) && (a > (INT_MAX - b))) ||
	      ((b < 0) && (a < (INT_MIN - b)))) {
	  
	  		printf("Can't Calculate Sum For Given x And y Values");
	  
	  } else {
	  
	    	result = a + b;
	  }

	  return result;
}

//______________________________________________________



// Function : playWithSum
// Result : 30
//  x: 2147483647 
//  y: 1
// Result : -2147483648
//  x: -2147483648 
//  y: -2
// Result : 2147483646

//______________________________________________________
// Choices Are
// 	1. Compile Time Error (CTE)
//	2. Runtime Error
//	3. Oye Hoye!!!
//	4. Wah Wah!!!

void playWithIfElse() {
	// Experssions Are Statements With Return Values
	//		

	int x = -10;
	int y = 0;

	// Any expression which evaluates to int Value
	//		If value is non-zero than it true
	//		otherwise it will be false
	// if ( expression ) { } else { }
	if ( x ) {
		printf("\nOye Hoye!!!");
	} else {
		printf("\nWah Wah!!!");
	}

	// Statemeent
	if ( x ) {
		y = 10;
	} else {
		y = 99;
	}

	// Expression
	y =  ( x ) ? 10 : 99;
	int yy = 400 +  (( x ) ? 10 : 99) + 999 ;

	// int tt = 400 + ( if ( x ) {
	// 	y = 10;
	// } else {
	// 	y = 99;
	// }) + 999;
}


//______________________________________________________
//______________________________________________________
//______________________________________________________
//______________________________________________________
//______________________________________________________
//______________________________________________________
//______________________________________________________
//______________________________________________________
//______________________________________________________
//______________________________________________________

void main() {
	printf("\nFunction : playWithSum");
	playWithSum();

	printf("\nFunction : playWithIfElse");
	playWithIfElse();
}

