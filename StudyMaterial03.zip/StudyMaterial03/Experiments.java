
// package learnJava;

public class Experiments {
	public static void main( String[] args ) {
		// 1. Compare Output Of Following Expressions 
		// 		In C/C++/Java/Kotlin and Python
		// 2. In Mathematics What Is Divide By Zero?
		// 3. Which Programming Language Implements
		//		Or Near To Mathematical Definition

		// try {
			System.out.println( 1.0 / 0.0 );
			System.out.println( -1.0 / 0.0 );
			System.out.println( 0.0 / 0.0 );
		// catch (Exception ) {
		// 	// Handler Logic
		// 	System.out.println("Handling Error...")
		// }

		// Infinity
		// -Infinity
		// NaN // Not A Number

		System.out.println( 1.0 / 0.0 == Double.POSITIVE_INFINITY );
		System.out.println( -1.0 / 0.0 == Double.NEGATIVE_INFINITY );
		System.out.println( 0.0 / 0.0 == Double.NaN );

		// System.out.println( 1.0 / 0.0 == Double.POSITIVE_INFINITY );
		float f1 = 1.0f;
		float f2 = 0.0f;
		if ( f1 / f2 == Double.POSITIVE_INFINITY ) {
			System.out.println("It's Infinite Error...");
		} else {
			System.out.println("Allow Access...");
		}
		
		// System.out.println( -1.0 / 0.0 == Double.NEGATIVE_INFINITY );
		f1 = -1.0f;
		f2 = 0.0f;
		if ( f1 / f2 == Double.NEGATIVE_INFINITY ) {
			System.out.println("It's Infinite Error...");
		} else {
			System.out.println("Allow Access...");
		}

		f1 = 0.0f;
		f2 = 0.0f;
		// System.out.println( 0.0 / 0.0 == Double.NaN );
		if ( 0.0 / 0.0 == Double.NaN ) {
			System.out.println("It's Non A Number Error...");
		} else {
			System.out.println("Allow Access...");
		}

		// true
		// true
		// false
	}
}
