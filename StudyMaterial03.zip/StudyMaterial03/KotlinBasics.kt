
package learnKotlin

//________________________________________________________________
//________________________________________________________________

// Creating New Type Color
// Color Type
//		Range Color Type = { RED, GREEN, BLUE, YELLOW, VIOLET, UNKNOWN }
enum class Color {
	RED, GREEN, BLUE, YELLOW, VIOLET, UNKNOWN
}

fun getStringForColor( color: Color ): String {
	// when Is Type Safe Expression
	//		Respect Type Definition
	return when( color ) {
		Color.RED 		-> "Red Color"
		Color.GREEN 	-> "Green Color"

		// error: 'when' expression must be exhaustive, add necessary 'BLUE' branch 
		//	or 'else' branch instead
		
		// Which Design Choice Is Better?
		Color.BLUE  	-> "Blue Color"
		Color.YELLOW 	-> "Yellow Color"
		Color.VIOLET 	-> "Violet Color"
		Color.UNKNOWN 	-> "Unkown Color"

		// else 		-> "Unknown Color"
	}
	//BETTER DESIGN
	//		Cover All The Exhaustive Cases i.e. Range of Type
}

fun getStringForColorAgain( color: Color ) = when( color ) {
		Color.RED 		-> "Red Color"
		Color.GREEN 	-> "Green Color"
		Color.BLUE  	-> "Blue Color"
		Color.YELLOW 	-> "Yellow Color"
		Color.VIOLET 	-> "Violet Color"
		Color.UNKNOWN 	-> "Unkown Color"

		// else 		-> "Unknown Color"
}


fun playWithColors() {
	println( Color.RED )
	println( Color.GREEN )
	println( Color.BLUE )

	println( getStringForColor( Color.RED ) )
	println( getStringForColor( Color.GREEN ) )
	println( getStringForColor( Color.BLUE ) )

	println( getStringForColorAgain( Color.RED ) )
	println( getStringForColorAgain( Color.GREEN ) )
	println( getStringForColorAgain( Color.BLUE ) )
}

//________________________________________________________________

fun mixColors( c1: Color, c2: Color ) = when ( setOf( c1, c2) ) {
	setOf( Color.BLUE, Color.GREEN ) 	-> Color.YELLOW
	setOf( Color.RED, Color.BLUE   )    -> Color.VIOLET
	else ->	throw Exception("Unknown Color")
}

// DESIGN PRINCIPLE
//		Exceptions Are Not That Exceptional Such That It Should Break Your Design

// Closure Law
fun mixColorsAgain( c1: Color, c2: Color ) : Color {
	return when ( setOf( c1, c2) ) {
		setOf( Color.BLUE, Color.GREEN ) 	-> Color.YELLOW
		setOf( Color.RED, Color.BLUE   )    -> Color.VIOLET
		else ->	Color.UNKNOWN
	}
}

fun playWithColorsAgain() {
	println( mixColors( Color.RED, Color.BLUE ) )
	println( mixColors( Color.GREEN, Color.BLUE ) )
	// println( mixColors( Color.BLUE, Color.YELLOW ) )

	println( mixColorsAgain( Color.RED, Color.BLUE ) )
	println( mixColorsAgain( Color.GREEN, Color.BLUE ) )
}

//________________________________________________________________

interface Expr
// Type Of Type Relationship
// Num Type Is Of Type Expression
// Implementing Interface Expression
class Num( val value: Int ) : Expr
class Sum( val left: Expr, val right: Expr ) : Expr

fun eval( expression: Expr ) : Int {
	// What Is The Type Of expression?
	//		Expr

	//  is Is A Type Checking Operator: Smart Type Casting
	//  expression is Num -- Checking Type
	//		 If It Results Into True
	//		 Type Casting Will Happen
	//		 Hence expression Typed Cast To Num Type
	if ( expression is Num ) {
	// What Is The Type Of expression?
	//		Num
		return expression.value
	} 

	// What Is The Type Of expression?
	//		Expr

	//  expression is Sum -- Checking Type
	//		 If It Results Into True
	//		 Type Casting Will Happen
	//		 Hence expression Typed Cast To Sum Type
	if ( expression is Sum ) {
	// What Is The Type Of expression?
	//		Sum
		return eval( expression.left ) + eval ( expression.right )
	}

	throw IllegalArgumentException("Unknown Expression!")
}

fun playWithEval() {
	//10 + 100
	println( eval( Sum( Num(10), Num(100) ) ) )
	
	// (10 + 100) + 5000
	println( eval( Sum( Sum( Num(10), Num(100) ), Num(5000) )  ) )

}

//________________________________________________________________

// 1. Type Inferrencing From RHS
// 2. Type Binding Happens With LHS
fun max(a: Int, b: Int) : Int {
	// In Kotlin
	//		if-else Construct Is An Expression
	return if ( a > b) a else b 

	// Last Expression Evaluated In A Block Will Be Return Value
	//		Every Value Have Type
	// return if ( a > b ) { 
	// 	a + 2
	// 	a + b
	// 	2 * a 
	// } else {
	// 	b
	// } 
}

fun maxAgain(a: Int, b: Int) = if ( a > b) a else b 
fun maxAgain1(a: Int, b: Int) = if ( a > b) a else "Hello" 
fun maxAgain2(a: Int, b: Int): Any = if ( a > b) a else "Hello" 

fun playWithMax() {
	println( max(100, 200) )
	println( max(100, -200) )

	println( maxAgain(100, 200) )
	println( maxAgain(100, -200) )

	// println( maxAgain1(100, -200) )
}


//________________________________________________________________

fun evalIf( expression: Expr ) : Int {
	if ( expression is Num ) {
		return expression.value
	} else if ( expression is Sum ) {
		return evalIf( expression.left ) + evalIf ( expression.right )
	} else {
		throw IllegalArgumentException("Unknown Expression!")
	}
}

fun playWithEvalIf() {
	//10 + 100
	println( evalIf( Sum( Num(10), Num(100) ) ) )
	
	// (10 + 100) + 5000
	println( evalIf( Sum( Sum( Num(10), Num(100) ), Num(5000) )  ) )

}

//________________________________________________________________

fun evalIfAgain( expression: Expr ) : Int = if ( expression is Num ) {
		expression.value
	} else if ( expression is Sum ) {
		evalIfAgain( expression.left ) + evalIfAgain ( expression.right )
	} else {
		throw IllegalArgumentException("Unknown Expression!")
}


fun playWithEvalIfAgain() {
	//10 + 100
	println( evalIfAgain( Sum( Num(10), Num(100) ) ) )
	
	// (10 + 100) + 5000
	println( evalIfAgain( Sum( Sum( Num(10), Num(100) ), Num(5000) )  ) )
}

//________________________________________________________________

// DESIGN PRINCIPLE
//		CODE IS A DOCUMENTATION
//		CODE IS DESIGN

// Linus Torvald
//		TALK IS CHEAP, SHOW ME THE CODE!!!

// error: type checking has run into a recursive problem. 
// Easiest workaround: specify types of your declarations explicitly

// fun evalulate( expression: Expr ) = when ( expression ) {
fun evalulate( expression: Expr ) : Int = when ( expression ) {
 	is Num  -> expression.value
	is Sum  -> evalulate( expression.left ) + evalulate ( expression.right )
	else  -> throw IllegalArgumentException("Unknown Expression!")
}

fun playWithEvaluate() {
	//10 + 100
	println( evalulate( Sum( Num(10), Num(100) ) ) )
	
	// (10 + 100) + 5000
	println( evalulate( Sum( Sum( Num(10), Num(100) ), Num(5000) )  ) )
}

//________________________________________________________________

fun isLetter( character: Char )   = character in 'a'..'z' || character in 'A'..'Z'
fun isNotDigit( character: Char ) = character !in '0'..'9'

fun recognise( character : Char ) = when( character ) {
	in '0'..'9' 				-> "It's Digit!"
	in 'a'..'z', in 'A'..'Z'	-> "It's Letter"
	else  						-> "Unknown Letter..."
}

//________________________________________________________________

// Usage Of when Expresion
// 		Pattern Matchings
fun fizzBuzz(i: Int) = when {
	i % 15 == 0 -> "FizzBuzz"
	i % 3  == 0 -> "Fizz"
	i % 5  == 0 -> "Buzz"
	else -> "$i"
}

//________________________________________________________________

fun fizzyBuzzyThings() {

	for( i in 1..50 ) { //[1, 50]
		print( fizzBuzz( i ) + "  " )
	}

	// error: the character literal does not conform 
	// to the expected type Int
	// for( i in 1..'A' ) { //[1, 50]
	// 	print( fizzBuzz( i ) + "  " )
	// }

	for( value in 'A'..'Z' ) { //['A', 'Z']
		print( value + " " )
	}

	// error: for-loop range must have an 'iterator()' method
	// for( value in 9.5..9.9 ) { //['A', 'Z']
	// 	print( value + " " )
	// }
}

//________________________________________________________________

fun playWithDataTypes() {
	// 1. Type Inferrencing From RHS
	// 2. Type Binding (Of Inferred Type) Happens With LHS

	var something = 42 // Type Inferred WIll Be Int
	println( something )

	var somethingAgain: Int = 42
	println( somethingAgain )

	var greeting = "Good Evening!" // Type Inferred Will Be Int
	println( greeting )

	var greetingAgain: String = "Good Evening!"
	println( greetingAgain )

//	In C/C++/Java/Kotlin
	// 90.90 or 90e+2 
	// Values In Point Form Or In Scientific Notation Form
	//		Default Type Will Be Double

// In Python
	// Python float Is Same As C/C++/Java/Kotlin double
	// i.e. It's Double Precision Floating Point
	// 	Python Doesn't Have float Similar To C/C++/Java/Kotlin
	// 			Python Doesn't Have Single Precision
	//			floating Point Similar To C/C++/Java/Kotlin

	// Following Two Definitons Are Equivalent
	var someValue = 90.90 
	println( someValue )

	var someValueAgain: Double = 90.90 
	println( someValueAgain )

	// 1. Type Inferrencing From RHS Is Double
	// 2. Type Binding (Of Inferred Type) Happens With LHS
	//			Before Binding Type Casting Will Happen
	//			Double Type Will Get Converted To Float Type
	//			Than Type Binding Happens

	// error: the floating-point literal does not conform to the 
	// expected type Float
	var someValueFloat: Float = 90.90F 
	println( someValue )
	println( someValueFloat )

	var somethingInt = 90
	var somethingDouble = somethingInt.toDouble() 
	println( somethingInt )
	println( somethingDouble )

	var someF1 : Float = 3.9998887893451F
	var someF2 : Float = 3.999888798987954998989F

	// Not Good Way Of Writing Code
	//		Don't Use Equality Operator To Compare Floating Points
	//		Following Code Is Non Deterministic In Nature	
	if ( someF1 == someF2 ) {
		println("Both Are Equal!")
	} else {
		println("Both Are UnEqual!")	
	}
}


//________________________________________________________________
//________________________________________________________________
//________________________________________________________________
//________________________________________________________________
//________________________________________________________________
//________________________________________________________________
//________________________________________________________________
//________________________________________________________________

fun main() {
	println("\nFunction : playWithColors")
	playWithColors()

	println("\nFunction : playWithColorsAgain")
	playWithColorsAgain()

	println("\nFunction : playWithEval")
	playWithEval()

	println("\nFunction : playWithMax")
	playWithMax()

	println("\nFunction : playWithEvalIf")
	playWithEvalIf()

	println("\nFunction : playWithEvalIfAgain")
	playWithEvalIfAgain()

	println("\nFunction : fizzyBuzzyThings")
	fizzyBuzzyThings()

	println("\nFunction : playWithDataTypes")
	playWithDataTypes()

	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
}

